# ⚡ Deploy Rápido - Depósito de Bebidas

## 🚀 Opção Mais Rápida: Railway (Recomendado)

Railway é a forma mais rápida para fazer deploy com suporte completo a banco de dados.

### 1️⃣ Preparar repositório GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/seu-usuario/wine-cellar.git
git push -u origin main
```

### 2️⃣ Acessar Railway

1. Vá para [railway.app](https://railway.app)
2. Faça login com GitHub
3. Clique em "New Project"
4. Selecione "Deploy from GitHub repo"
5. Escolha seu repositório

### 3️⃣ Configurar banco de dados

1. No dashboard do Railway, clique em "New"
2. Selecione "Database" → "MySQL" ou "PostgreSQL"
3. Railway criará automaticamente a conexão

### 4️⃣ Adicionar variáveis de ambiente

No Railway Dashboard, vá para Variables e adicione:

```
DATABASE_URL=<copiado do banco Railway>
JWT_SECRET=sua_chave_secreta_aqui
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu_open_id
NODE_ENV=production
```

### 5️⃣ Deploy automático

✅ Pronto! Railway fará deploy automaticamente!

Seu site estará em: `https://seu-projeto-railway.up.railway.app`

---

## 📦 Alternativa: Render (Também Rápido)

### 1️⃣ Conectar repositório

1. Vá para [render.com](https://render.com)
2. Clique em "New +" → "Web Service"
3. Conecte seu repositório GitHub

### 2️⃣ Configurar build

- **Build Command:** `pnpm install && pnpm build`
- **Start Command:** `pnpm start`

### 3️⃣ Adicionar PostgreSQL

1. Clique em "New +" → "PostgreSQL"
2. Copie a `DATABASE_URL`

### 4️⃣ Configurar variáveis

Adicione todas as variáveis do arquivo `DEPLOY_GUIDE.md`

### 5️⃣ Deploy

Clique em "Deploy" e aguarde!

---

## 🐳 Alternativa: Docker (Para qualquer servidor)

### Build da imagem

```bash
docker build -t wine-cellar .
```

### Testar localmente

```bash
docker run -p 3000:3000 \
  -e DATABASE_URL="mysql://usuario:senha@host:3306/wine_cellar" \
  wine-cellar
```

### Push para Docker Hub

```bash
docker login
docker tag wine-cellar seu-usuario/wine-cellar:latest
docker push seu-usuario/wine-cellar:latest
```

### Usar em qualquer servidor com Docker

```bash
docker pull seu-usuario/wine-cellar:latest
docker run -p 3000:3000 \
  -e DATABASE_URL="sua_url_banco" \
  seu-usuario/wine-cellar:latest
```

---

## 🔑 Gerar JWT_SECRET Seguro

```bash
# No terminal
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copie o resultado e use como `JWT_SECRET`

---

## ✅ Checklist Pré-Deploy

- [ ] Repositório GitHub criado e código enviado
- [ ] Banco de dados criado na nuvem
- [ ] Variáveis de ambiente configuradas
- [ ] `DATABASE_URL` testada localmente
- [ ] Build local funcionando (`pnpm build`)
- [ ] Arquivo `Dockerfile` presente (se usar Docker)

---

## 🧪 Testar após deploy

1. Acesse a URL do seu site
2. Faça login
3. Teste adicionar um produto
4. Verifique se os dados persistem no banco

---

## 🆘 Problemas Comuns

### "Build failed"
```bash
# Teste localmente
pnpm install
pnpm build
```

### "Cannot connect to database"
- Verifique `DATABASE_URL`
- Confirme que o banco está acessível
- Adicione IP da plataforma ao firewall

### "Port already in use"
- Plataformas usam `process.env.PORT` automaticamente
- Não precisa fazer nada

---

## 📊 Comparação Rápida

| Plataforma | Tempo Setup | Custo | Facilidade |
|-----------|-----------|-------|-----------|
| Railway | ⚡ 5 min | Grátis/Pago | ⭐⭐⭐⭐⭐ |
| Render | ⚡ 10 min | Grátis/Pago | ⭐⭐⭐⭐ |
| Docker | ⏱️ 15 min | Variável | ⭐⭐⭐ |
| Vercel | ⏱️ 20 min | Grátis/Pago | ⭐⭐⭐⭐ |

---

**Dica:** Railway é a mais rápida e fácil para começar!

Qualquer dúvida, consulte `DEPLOY_GUIDE.md` para instruções detalhadas.

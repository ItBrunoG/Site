# 🚀 Guia Completo de Deploy - Depósito de Bebidas

Este guia fornece instruções detalhadas para fazer deploy da aplicação em diferentes plataformas de nuvem.

## 📋 Pré-requisitos Globais

- Node.js 18+ instalado localmente
- Git instalado
- Conta em uma plataforma de hospedagem (Vercel, Railway, Render, Heroku, etc)
- Banco de dados MySQL ou PostgreSQL na nuvem

---

## 🔧 Opção 1: Deploy em Vercel (Recomendado para Frontend)

Vercel é ideal para aplicações Next.js, mas também suporta Node.js com Express.

### Passo 1: Preparar o projeto

```bash
# Instale Vercel CLI globalmente
npm i -g vercel

# Faça login
vercel login
```

### Passo 2: Criar arquivo `vercel.json`

```json
{
  "buildCommand": "pnpm build",
  "outputDirectory": "dist",
  "devCommand": "pnpm dev",
  "env": {
    "DATABASE_URL": "@database_url",
    "JWT_SECRET": "@jwt_secret",
    "VITE_APP_ID": "@vite_app_id",
    "OAUTH_SERVER_URL": "@oauth_server_url",
    "VITE_OAUTH_PORTAL_URL": "@vite_oauth_portal_url"
  }
}
```

### Passo 3: Deploy

```bash
vercel --prod
```

### Passo 4: Configurar variáveis de ambiente

No dashboard do Vercel:
1. Vá para Settings → Environment Variables
2. Adicione todas as variáveis do `.env.local`

---

## 🚂 Opção 2: Deploy em Railway (Mais Simples)

Railway é excelente para full-stack com suporte nativo a banco de dados.

### Passo 1: Criar conta e projeto

1. Acesse [railway.app](https://railway.app)
2. Faça login com GitHub
3. Clique em "New Project" → "Deploy from GitHub repo"

### Passo 2: Conectar repositório GitHub

```bash
# Inicialize git se ainda não fez
git init
git add .
git commit -m "Initial commit"

# Crie um repositório no GitHub e faça push
git remote add origin https://github.com/seu-usuario/wine-cellar.git
git branch -M main
git push -u origin main
```

### Passo 3: Configurar no Railway

1. Selecione seu repositório
2. Railway detectará automaticamente que é um projeto Node.js
3. Adicione um banco de dados MySQL/PostgreSQL pelo dashboard

### Passo 4: Definir variáveis de ambiente

No Railway Dashboard:
1. Vá para Variables
2. Adicione:
   ```
   DATABASE_URL=<conexão do banco Railway>
   JWT_SECRET=sua_chave_secreta
   VITE_APP_ID=seu_app_id
   NODE_ENV=production
   ```

### Passo 5: Deploy automático

Railway faz deploy automático a cada push no GitHub!

---

## 🎯 Opção 3: Deploy em Render

Render oferece hospedagem gratuita com SSL automático.

### Passo 1: Preparar repositório

```bash
git init
git add .
git commit -m "Initial commit"
git push origin main
```

### Passo 2: Criar Web Service no Render

1. Acesse [render.com](https://render.com)
2. Clique em "New +" → "Web Service"
3. Conecte seu repositório GitHub
4. Configure:
   - **Name:** wine-cellar-inventory
   - **Environment:** Node
   - **Build Command:** `pnpm install && pnpm build`
   - **Start Command:** `pnpm start`

### Passo 3: Adicionar banco de dados

1. Clique em "New +" → "PostgreSQL"
2. Configure o banco
3. Copie a `DATABASE_URL` fornecida

### Passo 4: Configurar variáveis

No Render Dashboard → Environment:
```
DATABASE_URL=<do PostgreSQL>
JWT_SECRET=sua_chave_secreta
NODE_ENV=production
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im
```

---

## 🐳 Opção 4: Deploy com Docker (Qualquer Servidor)

### Passo 1: Criar `Dockerfile`

```dockerfile
FROM node:22-alpine

WORKDIR /app

# Instalar pnpm
RUN npm install -g pnpm

# Copiar arquivos
COPY package.json pnpm-lock.yaml ./
RUN pnpm install --frozen-lockfile

COPY . .

# Build
RUN pnpm build

# Expor porta
EXPOSE 3000

# Iniciar
CMD ["pnpm", "start"]
```

### Passo 2: Criar `.dockerignore`

```
node_modules
.git
dist
.env
.env.local
.manus-logs
```

### Passo 3: Build e teste localmente

```bash
docker build -t wine-cellar .
docker run -p 3000:3000 -e DATABASE_URL="..." wine-cellar
```

### Passo 4: Deploy em Docker Hub ou Registry

```bash
# Fazer login
docker login

# Tag da imagem
docker tag wine-cellar seu-usuario/wine-cellar:latest

# Push
docker push seu-usuario/wine-cellar:latest
```

---

## 💾 Configuração do Banco de Dados na Nuvem

### Opção A: MySQL (AWS RDS, PlanetScale, etc)

```env
DATABASE_URL=mysql://usuario:senha@host:3306/wine_cellar
```

### Opção B: PostgreSQL (Railway, Render, Heroku)

```env
DATABASE_URL=postgresql://usuario:senha@host:5432/wine_cellar
```

### Aplicar migrations na nuvem

```bash
# Localmente com conexão remota
DATABASE_URL="sua_url_remota" pnpm db:push
```

---

## 🔐 Variáveis de Ambiente Necessárias

Todas as plataformas precisam dessas variáveis:

```env
# Banco de Dados (OBRIGATÓRIO)
DATABASE_URL=mysql://usuario:senha@host:3306/wine_cellar

# Autenticação
JWT_SECRET=gere_uma_chave_segura_aqui
VITE_APP_ID=seu_app_id_manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im

# Informações do Proprietário
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu_open_id

# APIs Manus (opcional)
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave_api
VITE_FRONTEND_FORGE_API_KEY=sua_chave_frontend
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im

# Produção
NODE_ENV=production
```

---

## 🧪 Testar antes de fazer deploy

```bash
# Build local
pnpm build

# Testar produção localmente
pnpm start

# Acessar em http://localhost:3000
```

---

## 📊 Comparação de Plataformas

| Plataforma | Custo | Facilidade | Suporte BD | Melhor Para |
|-----------|-------|-----------|-----------|-----------|
| **Vercel** | Grátis/Pago | ⭐⭐⭐⭐⭐ | Não | Frontend + Serverless |
| **Railway** | Grátis/Pago | ⭐⭐⭐⭐⭐ | ✅ Sim | Full-stack |
| **Render** | Grátis/Pago | ⭐⭐⭐⭐ | ✅ Sim | Full-stack |
| **Heroku** | Pago | ⭐⭐⭐⭐ | ✅ Sim | Full-stack |
| **AWS** | Pago | ⭐⭐⭐ | ✅ Sim | Escalável |
| **Docker** | Variável | ⭐⭐⭐ | ✅ Sim | Qualquer servidor |

---

## 🐛 Troubleshooting

### Erro: "DATABASE_URL is not set"
- Verifique se a variável está configurada na plataforma
- Teste localmente com `.env.local`

### Erro: "Port already in use"
- A porta 3000 pode estar em uso
- Plataformas usam `process.env.PORT` automaticamente

### Erro: "Build failed"
- Execute `pnpm build` localmente para testar
- Verifique se todas as dependências estão em `package.json`

### Erro: "Cannot connect to database"
- Verifique a `DATABASE_URL`
- Confirme que o banco está acessível da nuvem
- Adicione IP da plataforma ao firewall do banco

---

## 📱 Monitoramento Pós-Deploy

### Verificar logs
- **Vercel:** Dashboard → Deployments → Logs
- **Railway:** Dashboard → Logs
- **Render:** Dashboard → Logs

### Monitorar performance
- Adicione ferramentas como Sentry, DataDog, ou New Relic
- Configure alertas para erros

### Backup do banco de dados
- Configure backups automáticos na plataforma
- Teste restauração regularmente

---

## 🎉 Próximos Passos

1. ✅ Escolha uma plataforma
2. ✅ Configure o banco de dados
3. ✅ Defina variáveis de ambiente
4. ✅ Faça deploy
5. ✅ Teste a aplicação
6. ✅ Configure domínio customizado (opcional)
7. ✅ Configure SSL (geralmente automático)

---

**Versão:** 1.0.0  
**Última atualização:** Fevereiro 2026

# 📦 Depósito de Bebidas - Instruções de Configuração

## Pré-requisitos

- **Node.js** 18+ (recomendado 22.x)
- **pnpm** (gerenciador de pacotes)
- **MySQL** ou **PostgreSQL** (para o banco de dados)

## Instalação Local

### 1. Extrair o arquivo
```bash
unzip wine_cellar_inventory.zip
cd wine_cellar_inventory
```

### 2. Instalar dependências
```bash
pnpm install
```

### 3. Configurar variáveis de ambiente

Crie um arquivo `.env.local` na raiz do projeto com as seguintes variáveis:

```env
# Banco de Dados
DATABASE_URL=mysql://usuario:senha@localhost:3306/wine_cellar

# Autenticação (opcional para desenvolvimento local)
JWT_SECRET=sua_chave_secreta_aqui
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im

# Informações do proprietário
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu_open_id

# APIs Manus (opcional)
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave_api
VITE_FRONTEND_FORGE_API_KEY=sua_chave_frontend
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
```

### 4. Configurar o banco de dados

```bash
# Gerar e aplicar migrations
pnpm db:push
```

### 5. Iniciar o servidor de desenvolvimento

```bash
pnpm dev
```

O servidor estará disponível em `http://localhost:3000`

## Estrutura do Projeto

```
wine_cellar_inventory/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── lib/           # Utilitários e configurações
│   │   └── index.css      # Estilos globais
│   └── index.html
├── server/                # Backend Express + tRPC
│   ├── routers.ts         # Definição das APIs
│   ├── db.ts              # Helpers de banco de dados
│   └── _core/             # Configuração interna
├── drizzle/               # Schema e migrations do banco
├── shared/                # Código compartilhado
└── package.json
```

## Principais Tecnologias

- **Frontend:** React 19 + TypeScript + Tailwind CSS
- **Backend:** Express + tRPC + Drizzle ORM
- **Banco de Dados:** MySQL/PostgreSQL
- **Autenticação:** Manus OAuth (opcional)

## Comandos Úteis

```bash
# Desenvolvimento
pnpm dev              # Inicia servidor de desenvolvimento

# Build
pnpm build            # Compila para produção
pnpm start            # Inicia servidor de produção

# Banco de Dados
pnpm db:push          # Gera e aplica migrations

# Testes
pnpm test             # Executa testes com Vitest

# Formatação
pnpm format           # Formata código com Prettier
```

## Customização

### Alterar Cores
Edite o arquivo `client/src/index.css` e modifique as variáveis CSS na seção `:root`.

### Adicionar Novos Campos
1. Edite `drizzle/schema.ts` para adicionar campos à tabela
2. Execute `pnpm db:push` para aplicar a migration
3. Atualize as APIs em `server/routers.ts`
4. Atualize o frontend em `client/src/pages/Home.tsx`

### Adicionar Novas Funcionalidades
1. Crie novos routers em `server/routers.ts`
2. Crie componentes em `client/src/pages/` ou `client/src/components/`
3. Use `trpc.sua_feature.useMutation()` ou `trpc.sua_feature.useQuery()` no frontend

## Troubleshooting

### Erro de conexão com banco de dados
- Verifique se o MySQL/PostgreSQL está rodando
- Confirme a `DATABASE_URL` está correta
- Verifique credenciais de acesso

### Porta 3000 já em uso
```bash
# Mude a porta no arquivo server/_core/index.ts
# ou use uma porta diferente
PORT=3001 pnpm dev
```

### Problemas com dependências
```bash
# Limpe cache e reinstale
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

## Suporte

Para dúvidas ou problemas, consulte a documentação do projeto ou abra uma issue.

---

**Versão:** 1.0.0  
**Última atualização:** Fevereiro 2026

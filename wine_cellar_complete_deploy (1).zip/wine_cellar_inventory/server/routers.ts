import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getUserWineProducts, createWineProduct, updateWineProduct, deleteWineProduct } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  wine: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserWineProducts(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          quantity: z.number().int().min(1),
          status: z.enum(["Em estoque", "Esgotado"]),
          entryDate: z.date(),
        })
      )
      .mutation(({ ctx, input }) =>
        createWineProduct({
          userId: ctx.user.id,
          name: input.name,
          quantity: input.quantity,
          status: input.status,
          entryDate: input.entryDate,
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number().int(),
          name: z.string().min(1).optional(),
          quantity: z.number().int().min(0).optional(),
          status: z.enum(["Em estoque", "Esgotado"]).optional(),
          entryDate: z.date().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...updates } = input;
        return updateWineProduct(id, updates);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number().int() }))
      .mutation(({ input }) => deleteWineProduct(input.id)),
  }),
});

export type AppRouter = typeof appRouter;

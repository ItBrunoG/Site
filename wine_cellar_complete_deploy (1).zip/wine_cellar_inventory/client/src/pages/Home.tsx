import { useState } from 'react';
import { Trash2, Edit2, Plus, Minus, X } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { toast } from 'sonner';

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    quantity: number;
    status: 'Em estoque' | 'Esgotado';
    entryDate: string;
  }>({
    name: '',
    quantity: 1,
    status: 'Em estoque',
    entryDate: new Date().toISOString().split('T')[0],
  });

  // Queries
  const { data: items = [], isLoading, refetch } = trpc.wine.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // Mutations
  const createMutation = trpc.wine.create.useMutation({
    onSuccess: () => {
      toast.success('Produto adicionado com sucesso!');
      refetch();
      setShowModal(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateMutation = trpc.wine.update.useMutation({
    onSuccess: () => {
      toast.success('Produto atualizado com sucesso!');
      refetch();
      setShowModal(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const deleteMutation = trpc.wine.delete.useMutation({
    onSuccess: () => {
      toast.success('Produto deletado com sucesso!');
      refetch();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      name: '',
      quantity: 1,
      status: 'Em estoque',
      entryDate: new Date().toISOString().split('T')[0],
    });
    setEditingId(null);
  };

  const handleNewItem = () => {
    setEditingId(null);
    resetForm();
    setShowModal(true);
  };

  const handleEditItem = (item: any) => {
    setEditingId(item.id);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      status: item.status,
      entryDate: item.entryDate.toISOString().split('T')[0],
    });
    setShowModal(true);
  };

  const handleSaveItem = async () => {
    if (!formData.name.trim()) {
      toast.error('Por favor, preencha o nome do produto');
      return;
    }

    const payload = {
      name: formData.name,
      quantity: formData.quantity,
      status: formData.status,
      entryDate: new Date(formData.entryDate),
    };

    if (editingId) {
      await updateMutation.mutateAsync({ id: editingId, ...payload });
    } else {
      await createMutation.mutateAsync(payload);
    }
  };

  const handleDeleteItem = (id: number) => {
    if (confirm('Tem certeza que deseja deletar este item?')) {
      deleteMutation.mutate({ id });
    }
  };

  const handleIncreaseQuantity = (id: number, currentQuantity: number) => {
    updateMutation.mutate({
      id,
      quantity: currentQuantity + 1,
      status: 'Em estoque',
    });
  };

  const handleDecreaseQuantity = (id: number, currentQuantity: number) => {
    if (currentQuantity > 0) {
      updateMutation.mutate({
        id,
        quantity: currentQuantity - 1,
      });
    }
  };

  // Calcular estatísticas
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const outOfStock = items.filter(item => item.status === 'Esgotado').length;
  const inStock = items.filter(item => item.status === 'Em estoque').length;

  // Formatar data
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Wine Cellar</h1>
          <p className="text-gray-600 mb-8">Faça login para gerenciar sua adega</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Depósito de Bebidas</h1>
              <p className="text-gray-600 mt-2">
                Gerenciamento eficiente de estoque
              </p>
            </div>
            <button
              onClick={handleNewItem}
              className="flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-300 shadow-sm hover:shadow-md"
            >
              <Plus size={20} />
              Novo Produto
            </button>
          </div>
        </div>
      </header>

      {/* Dashboard Stats */}
      <section className="bg-gradient-to-r from-gray-50 to-white py-8 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Total de Produtos */}
            <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Total em Estoque</p>
                  <p className="text-4xl font-bold text-blue-900 mt-2">{totalItems}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">📦</span>
                </div>
              </div>
            </div>

            {/* Disponível */}
            <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Disponível</p>
                  <p className="text-4xl font-bold text-emerald-600 mt-2">{inStock}</p>
                </div>
                <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">✓</span>
                </div>
              </div>
            </div>

            {/* Fora de Estoque */}
            <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Fora de Estoque</p>
                  <p className="text-4xl font-bold text-rose-600 mt-2">{outOfStock}</p>
                </div>
                <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">✕</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-gray-600">Carregando...</p>
            </div>
          ) : items.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📭</div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                Depósito vazio
              </h2>
              <p className="text-gray-600 mb-6">
                Comece adicionando seus primeiros produtos ao estoque
              </p>
              <button
                onClick={handleNewItem}
                className="inline-flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-300"
              >
                <Plus size={20} />
                Adicionar Produto
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-gray-200">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-blue-900 bg-blue-50">
                    <th className="text-left py-4 px-4 font-semibold text-blue-900">
                      Produto
                    </th>
                    <th className="text-left py-4 px-4 font-semibold text-blue-900">
                      Data de Entrada
                    </th>
                    <th className="text-center py-4 px-4 font-semibold text-blue-900">
                      Quantidade
                    </th>
                    <th className="text-center py-4 px-4 font-semibold text-blue-900">
                      Status
                    </th>
                    <th className="text-center py-4 px-4 font-semibold text-blue-900">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-all duration-300"
                    >
                      <td className="py-4 px-4">
                        <p className="font-medium text-gray-900">{item.name}</p>
                      </td>
                      <td className="py-4 px-4 text-gray-600">
                        {formatDate(item.entryDate)}
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleDecreaseQuantity(item.id, item.quantity)}
                            className="p-1 hover:bg-gray-200 rounded transition-all duration-300"
                            title="Diminuir quantidade"
                          >
                            <Minus size={18} className="text-gray-600" />
                          </button>
                          <span className="w-8 text-center font-semibold text-gray-900">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => handleIncreaseQuantity(item.id, item.quantity)}
                            className="p-1 hover:bg-gray-200 rounded transition-all duration-300"
                            title="Aumentar quantidade"
                          >
                            <Plus size={18} className="text-gray-600" />
                          </button>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                            item.status === 'Esgotado'
                              ? 'bg-rose-600 text-white'
                              : 'bg-emerald-600 text-white'
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditItem(item)}
                            className="p-2 hover:bg-yellow-100 rounded transition-all duration-300"
                            title="Editar"
                          >
                            <Edit2 size={18} className="text-yellow-600" />
                          </button>
                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-2 hover:bg-red-100 rounded transition-all duration-300"
                            title="Deletar"
                          >
                            <Trash2 size={18} className="text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? 'Editar Produto' : 'Novo Item de Estoque'}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-1 hover:bg-gray-100 rounded transition-all duration-300"
              >
                <X size={24} className="text-gray-600" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Nome do Produto */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome do Produto
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Ex: Vinho Tinto Reserva"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600 focus:border-transparent"
                />
              </div>

              {/* Data de Entrada */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data de Entrada
                </label>
                <input
                  type="date"
                  value={formData.entryDate}
                  onChange={(e) =>
                    setFormData({ ...formData, entryDate: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600 focus:border-transparent"
                />
              </div>

              {/* Quantidade */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantidade
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.quantity}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      quantity: Math.max(1, parseInt(e.target.value) || 1),
                    })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600 focus:border-transparent"
                />
              </div>

              {/* Status */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="Em estoque"
                      checked={formData.status === 'Em estoque'}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          status: e.target.value as 'Em estoque' | 'Esgotado',
                        })
                      }
                      className="w-4 h-4 accent-yellow-600"
                    />
                    <span className="text-gray-700">Em estoque</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="Esgotado"
                      checked={formData.status === 'Esgotado'}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          status: e.target.value as 'Em estoque' | 'Esgotado',
                        })
                      }
                      className="w-4 h-4 accent-yellow-600"
                    />
                    <span className="text-gray-700">Esgotado</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Botões */}
            <div className="flex gap-3 mt-8">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-all duration-300"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveItem}
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-all duration-300 disabled:opacity-50"
              >
                {editingId ? 'Atualizar' : 'Adicionar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
